package com.example.touristguide;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;
import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends AppCompatActivity {
    private LocationHandler locationHandler;
    private DirectionsHandler directionsHandler;
    private List<Marker> allMarkers = new ArrayList<>();
    private MarkerLoader markerLoader;
    private Button clearButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_activity_main);

        directionsHandler = new DirectionsHandler();

        PlacesApiClient placesApiClient = new PlacesApiClient(BuildConfig.MAPS_API_KEY);

        setupMapFragment();

        setupPlacesClient();

        setupFilterButton();
    }

    private void setupMapFragment() {
        SupportMapFragment mapFragment = new SupportMapFragment();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.mapFragment, mapFragment)
                .commit();

        mapFragment.getMapAsync(this::onMapReady);
    }

    @SuppressLint("PotentialBehaviorOverride")
    private void onMapReady(@NonNull GoogleMap map) {
        markerLoader = new MarkerLoader(map);
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        locationHandler = new LocationHandler(this, map, fusedLocationClient);
        locationHandler.initializeLocation();
        map.setOnMarkerClickListener(marker -> {
            showNavigationButton(marker, map);
            clearButton.setOnClickListener(v -> clearDirections());
            return false;
        });
    }
    private void clearDirections() {
        if (directionsHandler != null) {
            directionsHandler.clearPolylines();
        }
    }

    private void showNavigationButton(Marker marker, GoogleMap map) {
        View buttonLayout = getLayoutInflater().inflate(R.layout.navi_button, null);
        Button navigationButton = buttonLayout.findViewById(R.id.navigateButton);
        View buttonLayout2 = getLayoutInflater().inflate(R.layout.clear_polyline, null);
        clearButton = buttonLayout2.findViewById(R.id.clearButton);

        if (navigationButton != null) {
            navigationButton.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            navigationButton.setVisibility(View.VISIBLE);
            navigationButton.setOnClickListener(v -> showNavigationConfirmationDialog(marker, map));
        } else {
            Log.e("MapsActivity", "Button not found in layout");
        }

        ViewGroup rootView = findViewById(android.R.id.content);
        rootView.addView(buttonLayout);
        rootView.addView(buttonLayout2);
    }

    private void showNavigationConfirmationDialog(Marker clickedMarker, GoogleMap map) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Do you want to navigate to this place?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    if (clickedMarker != null) {
                        LatLng destination = clickedMarker.getPosition();
                        buildDirections(destination, map);
                    } else {
                        showEnableLocationNotice();
                    }
                })
                .setNegativeButton("No", (dialog, which) -> {
                    // User clicked "No," do nothing
                })
                .create()
                .show();
    }

    private void showEnableLocationNotice() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Please enable location services to use navigation.")
                .setPositiveButton("OK", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    startActivity(intent);
                })
                .create()
                .show();
    }

    private void buildDirections(LatLng destination, GoogleMap map) {
        if (locationHandler != null && locationHandler.getCurrentUserLocation() != null) {
            LatLng origin = locationHandler.getCurrentUserLocation();
            directionsHandler.drawDirections(origin, destination, map,BuildConfig.MAPS_API_KEY);
        } else {
            showEnableLocationNotice();
        }
    }

    private void setupPlacesClient() {
        Places.initialize(getApplicationContext(), BuildConfig.MAPS_API_KEY);
        PlacesClient placesClient = Places.createClient(this);
    }

    private void setupFilterButton() {
        Button filtersButton = findViewById(R.id.filterButton);
        filtersButton.setOnClickListener(v -> showFilterOptions());
    }

    private void showFilterOptions() {
        View spinnerView = getLayoutInflater().inflate(R.layout.filter_menu, null);
        Spinner filterSpinner = spinnerView.findViewById(R.id.filterSpinner);

        List<String> filterOptions = getFilterOptions();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, filterOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        filterSpinner.setAdapter(adapter);

        filterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedFilter = (String) parentView.getItemAtPosition(position);
                createMapWithFilter(selectedFilter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing
            }
        });
    }

    @SuppressLint("PotentialBehaviorOverride")
    private void createMapWithFilter(String selectedFilter) {
        // Clear existing markers
        clearMarkers();

        // Filter the markers based on the selected filter
        List<Marker> filteredMarkers = filterMarkers(selectedFilter);

        // Create a new map with filtered markers
        SupportMapFragment mapFragment = new SupportMapFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.mapFragment, mapFragment)
                .commit();

        mapFragment.getMapAsync(map -> {
            markerLoader = new MarkerLoader(map);
            FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            locationHandler = new LocationHandler(this, map, fusedLocationClient);
            locationHandler.initializeLocation();

            // Add filtered markers to the map
            for (Marker marker : filteredMarkers) {
                markerLoader.addMarker(marker,map);
            }

            map.setOnMarkerClickListener(marker -> {
                showNavigationButton(marker, map);
                clearButton.setOnClickListener(v -> clearDirections());
                return false;
            });
        });
    }

    private void clearMarkers() {
        if (markerLoader != null) {
            markerLoader.clearMarkers();
        }
    }
    private List<String> getFilterOptions() {
        List<String> filters = new ArrayList<>();
        filters.add("Museums");
        filters.add("Restaurants");
        filters.add("Hotels");
        filters.add("Sights");
        return filters;
    }

    private List<Marker> filterMarkers(String selectedFilter) {
        List<Marker> filteredMarkers = new ArrayList<>();

        for (Marker marker : allMarkers) {
            String markerType = marker.getSnippet(); // Assuming snippet contains the type
            if (markerType != null && markerType.contains(selectedFilter)) {
                filteredMarkers.add(marker);
            }
        }
        return filteredMarkers;
    }

}