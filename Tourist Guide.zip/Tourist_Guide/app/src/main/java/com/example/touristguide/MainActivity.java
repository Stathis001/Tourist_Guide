package com.example.touristguide;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends FragmentActivity implements View.OnClickListener {

    Button startButton , languageButton;

    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_screen);
        languageButton = findViewById(R.id.languageButton);
        languageButton.setOnClickListener(this::OnLanguageButtonClick);
        startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(v.getContext(), MapsActivity.class);
        startActivity(intent);
    }

    public void OnLanguageButtonClick(View v){
        setContentView(R.layout.languages_list);

        List<String> supportedLanguages = Arrays.asList(getString(R.string.english), getString(R.string.greek), getString(R.string.german));

        RecyclerView recyclerView = findViewById(R.id.languagesRecyclerView);
        LanguageAdapter adapter = new LanguageAdapter(this, supportedLanguages);
        recyclerView.setAdapter(adapter);

        // Set item click listener
        adapter.setOnItemClickListener(language -> {
            // Handle item click, for example, show a Toast with the selected language
            Toast.makeText(this, getString(R.string.selected_language) + language, Toast.LENGTH_SHORT).show();
            changeLanguage(language);
        });

    }
    private void changeLanguage(String language) {
            LocaleListCompat appLocale;
            if (language.equals(R.string.english)){
                appLocale = LocaleListCompat.forLanguageTags("en");
            } else if (language.equals(R.string.greek)) {
                appLocale = LocaleListCompat.forLanguageTags("el");
            } else {
                appLocale = LocaleListCompat.forLanguageTags("de");
            }
            AppCompatDelegate.setApplicationLocales(appLocale);
    }
}
