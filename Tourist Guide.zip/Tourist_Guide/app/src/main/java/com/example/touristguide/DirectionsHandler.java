package com.example.touristguide;

import android.graphics.Color;
import android.os.AsyncTask;
import android.util.Log;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DirectionsHandler {
    private static List<Polyline> polylines;

    public DirectionsHandler() {
        this.polylines = new ArrayList<>();
    }

    public void drawDirections(LatLng origin, LatLng destination, GoogleMap map, String apiKey) {
        String url = buildDirectionsUrl(origin, destination, apiKey);
        new DirectionsTask(map).execute(url);
    }

    String buildDirectionsUrl(LatLng origin, LatLng destination, String apiKey) {
        return "https://maps.googleapis.com/maps/api/directions/json" +
                "?origin=" + origin.latitude + "," + origin.longitude +
                "&destination=" + destination.latitude + "," + destination.longitude +
                "&mode=driving" +
                "&key=" + apiKey;
    }

    static class DirectionsTask extends AsyncTask<String, Void, List<LatLng>> {
        private final GoogleMap map;

        public DirectionsTask(GoogleMap map) {
            this.map = map;
        }

        @Override
        protected List<LatLng> doInBackground(String... urls) {
            String response = getDirectionsData(urls[0]);
            return parseDirections(response);
        }

        @Override
        protected void onPostExecute(List<LatLng> result) {
            if (result != null && !result.isEmpty()) {
                PolylineOptions options = new PolylineOptions()
                        .addAll(result)
                        .width(12)
                        .color(Color.BLUE);

                Polyline newPolyline = map.addPolyline(options);
                polylines.add(newPolyline);
            }
        }

        private String getDirectionsData(String url) {
            StringBuilder response = new StringBuilder();
            OkHttpClient client = new OkHttpClient();

            try {
                Request request = new Request.Builder()
                        .url(url)
                        .build();

                Response httpResponse = client.newCall(request).execute();
                response.append(httpResponse.body().string());
            } catch (IOException e) {
                Log.e("DirectionsHandler", "Error in getting directions data", e);
            }

            return response.toString();
        }

        private List<LatLng> parseDirections(String jsonData) {
            List<LatLng> path = new ArrayList<>();
            try {
                JsonObject jsonObject = JsonParser.parseString(jsonData).getAsJsonObject();
                JsonArray routes = jsonObject.getAsJsonArray("routes");
                if (routes.size() > 0) {
                    JsonArray steps = routes.get(0).getAsJsonObject().getAsJsonArray("legs")
                            .get(0).getAsJsonObject().getAsJsonArray("steps");

                    for (int i = 0; i < steps.size(); i++) {
                        JsonObject step = steps.get(i).getAsJsonObject();
                        JsonObject startLocation = step.getAsJsonObject("start_location");
                        double lat = startLocation.getAsJsonPrimitive("lat").getAsDouble();
                        double lng = startLocation.getAsJsonPrimitive("lng").getAsDouble();
                        path.add(new LatLng(lat, lng));

                        JsonObject endLocation = step.getAsJsonObject("end_location");
                        lat = endLocation.getAsJsonPrimitive("lat").getAsDouble();
                        lng = endLocation.getAsJsonPrimitive("lng").getAsDouble();
                        path.add(new LatLng(lat, lng));
                    }
                }
            } catch (Exception e) {
                Log.e("DirectionsHandler", "Error in parsing directions data", e);
            }
            return path;
        }
    }

    public void clearPolylines() {
        for (Polyline polyline : polylines) {
            polyline.remove();
        }
        polylines.clear();
    }

    public List<Polyline> getPolylines() {
        return polylines;
    }
}