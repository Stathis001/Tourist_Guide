package com.example.touristguide;

import static android.provider.Settings.System.getString;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.PlaceLikelihood;
import com.google.android.libraries.places.api.net.PlacesClient;

import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.FindCurrentPlaceRequest;
import com.google.android.libraries.places.api.net.FindCurrentPlaceResponse;
import com.google.android.libraries.places.api.net.PlacesClient;

import java.util.Arrays;
import java.util.List;

public class MarkerLoader extends AppCompatActivity{
    private Marker clickedMarker;
    private List<Marker> allMarkers;
    public MarkerLoader(GoogleMap map) {
        addMarkersToMap(map);
    }
    @SuppressLint("PotentialBehaviorOverride")
    private void addMarkersToMap(GoogleMap map) {
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.092479913425834, 23.548556365564238)).title(getString(R.string.anastasios_eskitzis_reumatologos)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09034269429762, 23.55348399478657)).title(getString(R.string.maria_kokarida_wrila)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.08731152657037, 23.55017293627774)).title(getString(R.string.orthopaidiko_iatreio_enilikwn_kai_paidwn)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.07529662776701, 23.55353525970813)).title(getString(R.string.dipae)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09835129725971, 23.551927608268336)).title(getString(R.string.lofos_koyla)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09156654135183, 23.559917963233605)).title(getString(R.string.achmet_pasa_tzami)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.08828964518851, 23.553439602363994)).title(getString(R.string.Zilingiri_Tzami)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09146333054632, 23.55051494660206)).title(getString(R.string.liberty_square)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.090984162331786, 23.54966866588395)).title(getString(R.string.archeological_museum_of_serres_bezesteni)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.10059767457084, 23.57097613512557)).title(getString(R.string.natural_history_museum)).snippet(getString(R.string.this_is_marker_1_s_snippet))));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.10434890738389, 23.553423758489348)).title("Agioi Anargyroi Valley (Τουριστικό αξιοθέατο)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.07791797232521, 23.542626119426355)).title("Intercity Bus Station of Serres (Μέσα Μαζικής Μεταφοράς").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.07329171632362, 23.5470893150212)).title("Serres Camp (Σχολείο)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09486734480665, 23.558418965379346)).title("Philippos Xenia Hotel (Hotel)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.10347193488058, 23.549222483272818)).title("Elpida Resort & Spa (Hotel)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.08930648512539, 23.527421488950267)).title("Serres National Stadium (Αθλητικές Εγκαταστάσεις)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09293009514462, 23.55736205023394)).title("Serres State Health Center (Ιατρείο)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.0941120281705, 23.546161726125494)).title("Kalithea Serres (Τουριστικό αξιοθέατο)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.097588736734345, 23.551225736764437)).title("Cityζεν WINE · BAR · RESTAURANT (Χώρος Ψυχαγωγίας)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.082807410884556, 23.5425353795879)).title("Fire Service (Emergency Services)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.07275655544222, 23.51766362781244)).title("Serres Racing Circuit (Χώρος Ψυχαγωγίας)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.06602011402373, 23.54131497674441)).title("LA VITA CENTER (Χώρος Ψυχαγωγίας)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.084803498471516, 23.546518769143844)).title("Serres Municipal Stadium (Αθλητικές Εγκαταστάσεις)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.08315378520309, 23.551668610294023)).title("Ελλήνων Γεύσεις (Χώρος Ψυχαγωγίας)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.08084088215488, 23.541583504790097)).title("Bruno Coffee Stores (Χώρος Ψυχαγωγίας)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.08787638344969, 23.541433300952594)).title("ACS Courier (Υπηρεσίες)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.090423204868415, 23.58244886315631)).title("General Hospital of Serres (Ιατρείο)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09137601208604, 23.503011834688117)).title("Εργοστάσιο Ζάχαρης ΕΒΖ (Υπηρεσίες)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.14501059108502, 23.56798662373499)).title("Καταρράκτες του Ελαιώνας Eleonas Waterfall (Τουριστικό αξιοθέατο)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09299314426827, 23.515231717565964)).title("Lidl (Market)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.05052488942454, 23.53291159053017)).title("AUTOGAS SERRES (Υπηρεσίες)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.04257774991801, 23.52753457401081)).title("Shell (Gas Station)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.08450712812035, 23.58830568688104)).title("Αεροδρόμιο «Εμμανουήλ Παππάς (Αεροδρόμιο)»").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09094591627225, 23.600749255344375)).title("Bodyfit Σέρρες - Γυμναστήρια Σέρρες (Αθλητικές Εγκαταστάσεις)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.10935603117662, 23.488498349170314)).title("Joy Dog Club Ξενοδοχείο Σκύλων (Υπηρεσίες)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.0983612703665, 23.47249092575993)).title("JUMBO (Market)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.084980140470996, 23.502080266589516)).title("washer truck (Υπηρεσίες)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.085807177397065, 23.497308472294627)).title("Hobbytech Track-Πίστα (Χώρος Ψυχαγωγίας)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.097390282594645, 23.545074746638075)).title("Βυζαντινό Υδραγωγείο Σερρών (Ιστορικό αξιοθέατο)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.10109319034786, 23.551876828708686)).title("Κολυμβητήριο (θλητικές Εγκαταστάσεις)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09632970832197, 23.564652464585212)).title("Σνούπυ Academy | Κέντρο προσχολικής αγωγής (Σχολείο)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.09657008557742, 23.565883689570832)).title("ΚΩΣΤΟΠΟΥΛΕΙΟΣ ΣΤΕΓΗ Μονάδα Χρονίων Παθήσεων (Ιατρείο)").snippet("This is marker 1's snippet")));
        allMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(41.10368066471727, 23.55034040268912)).title("Θερινό Σινεμά (Χώρος Ψυχαγωγίας)").snippet("This is marker 1's snippet")));
        map.setOnMarkerClickListener(marker -> {
            // Save the clicked marker
            clickedMarker = marker;

            // Show a button when a marker is clicked
            showNavigationButton();

            // Return false to allow default behavior (open marker info window)
            return false;
        });
    }
    private void showNavigationButton() {
        // Show a button on the UI
        Button navigationButton = findViewById(R.id.navigateButton);
        navigationButton.setVisibility(View.VISIBLE);
        // Set a click listener for the button
        navigationButton.setOnClickListener(v -> showNavigationConfirmationDialog());
    }

    private void showNavigationConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Do you want to navigate to this place?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    // User clicked "Yes," build directions
                    if (clickedMarker != null) {
                        LatLng destination = clickedMarker.getPosition();
                        buildDirections(destination);
                    }
                })
                .setNegativeButton("No", (dialog, which) -> {
                    // User clicked "No," do nothing
                })
                .create()
                .show();
    }

    private void buildDirections(LatLng destination) {
        // Implement your logic to build directions to the destination
        // You might want to use Google Maps Directions API or other navigation libraries
        // For simplicity, we'll just log a message here
        Log.d("MapsActivity", "Building directions to: " + destination.toString());
    }
}
