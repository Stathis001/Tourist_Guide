package com.example.touristguide;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.util.Log;
import com.google.android.gms.maps.model.LatLng;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Locale;

public class PlacesApiClient {

    private static final String TAG = PlacesApiClient.class.getSimpleName();
    private static final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
    private static final String TYPE_DETAILS = "/details";
    private static final String OUT_JSON = "/json";

    private String apiKey;

    public PlacesApiClient(String apiKey) {
        this.apiKey = apiKey;
    }

    public void getPlaceDetails(LatLng location, String placeType, PlaceDetailsCallback callback) {
        new PlaceDetailsTask(callback, placeType).execute(location);
    }

    private class PlaceDetailsTask extends AsyncTask<LatLng, Void, String> {
        private PlaceDetailsCallback callback;
        private String placeType;

        public PlaceDetailsTask(PlaceDetailsCallback callback, String placeType) {
            this.callback = callback;
            this.placeType = placeType;
        }

        @Override
        protected String doInBackground(LatLng... params) {
            LatLng location = params[0];
            String urlString = buildPlaceDetailsUrl(location);

            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                InputStream stream = connection.getInputStream();
                java.util.Scanner s = new java.util.Scanner(stream).useDelimiter("\\A");
                return s.hasNext() ? s.next() : "";
            } catch (IOException e) {
                Log.e(TAG, "Error fetching place details", e);
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject json = new JSONObject(result);
                    parsePlaceDetails(json);
                } catch (JSONException e) {
                    Log.e(TAG, "Error parsing place details JSON", e);
                    callback.onPlaceDetailsError();
                }
            } else {
                callback.onPlaceDetailsError();
            }
        }

        private void parsePlaceDetails(JSONObject json) throws JSONException {
            // Extract information from the JSON response and pass it to the callback
            JSONObject result = json.getJSONObject("result");
            String placeName = result.getString("name");
            String address = result.getString("formatted_address");

            // Pass the place type to the callback
            callback.onPlaceDetailsSuccess(placeName, address, placeType);
        }

        private String buildPlaceDetailsUrl(LatLng location) {
            StringBuilder urlString = new StringBuilder(PLACES_API_BASE);
            urlString.append(TYPE_DETAILS);
            urlString.append(OUT_JSON);
            urlString.append("?placeid=").append(getPlaceId(location));
            urlString.append("&key=").append(apiKey);
            return urlString.toString();
        }

        private String getPlaceId(LatLng location) {
            Geocoder geocoder = new Geocoder(callback.getContext(), Locale.getDefault());
            List<Address> addresses;

            try {
                addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1);
                if (!addresses.isEmpty()) {
                    return addresses.get(0).getFeatureName();
                }
            } catch (IOException e) {
                Log.e(TAG, "Error obtaining place ID", e);
            }

            return "";
        }
    }

    public interface PlaceDetailsCallback {
        void onPlaceDetailsSuccess(String placeName, String address, String placeType);

        void onPlaceDetailsSuccess(String details);

        void onPlaceDetailsError();

        Context getContext();
    }
}