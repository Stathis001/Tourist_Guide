package com.example.touristguide;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.GoogleMap;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class LocationHandlerTest {

    @Mock
    private FragmentActivity mockActivity;

    @Mock
    private GoogleMap mockGoogleMap;

    @Mock
    private FusedLocationProviderClient mockFusedLocationClient;

    @Mock
    private Location mockLocation;

    @Captor
    private ArgumentCaptor<LocationRequest> locationRequestCaptor;

    private LocationHandler locationHandler;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        locationHandler = new LocationHandler(mockActivity, mockGoogleMap, mockFusedLocationClient);
    }

    @Test
    public void testInitializeLocation_WithPermissionGranted() {
        // Mocking permission granted
        when(ActivityCompat.checkSelfPermission(mockActivity, Manifest.permission.ACCESS_FINE_LOCATION))
                .thenReturn(PackageManager.PERMISSION_GRANTED);

        // Call the method to be tested
        locationHandler.initializeLocation();

        // Verify that enableMyLocation is called
        verify(locationHandler).enableMyLocation();
    }

    @Test
    public void testEnableMyLocation() {
        // Mocking permission granted
        when(ActivityCompat.checkSelfPermission(mockActivity, Manifest.permission.ACCESS_FINE_LOCATION))
                .thenReturn(PackageManager.PERMISSION_GRANTED);

        // Call the method to be tested
        locationHandler.enableMyLocation();

        // Verify that setMyLocationEnabled and startLocationUpdates are called
        verify(mockGoogleMap).setMyLocationEnabled(true);
        verify(locationHandler).startLocationUpdates();
    }

    @Test
    public void testStartLocationUpdates_WithPermissionGranted() {
        // Mocking permission granted
        when(ActivityCompat.checkSelfPermission(mockActivity, Manifest.permission.ACCESS_FINE_LOCATION))
                .thenReturn(PackageManager.PERMISSION_GRANTED);

        // Mocking a successful location request
        when(mockFusedLocationClient.requestLocationUpdates(any(LocationRequest.class), any(LocationCallback.class), any()))
                .thenReturn(null);  // Use null since requestLocationUpdates returns void

        // Call the method to be tested
        Location result = locationHandler.startLocationUpdates();

        // Verify that requestLocationUpdates is called with the correct parameters
        verify(mockFusedLocationClient).requestLocationUpdates(locationRequestCaptor.capture(), any(LocationCallback.class), any());
        LocationRequest capturedLocationRequest = locationRequestCaptor.getValue();
        assertEquals(5000, capturedLocationRequest.getInterval());

        // Assert the result (location) is the same as the mockLocation
        assertEquals(mockLocation, result);
    }

    // Add more test methods as needed

}