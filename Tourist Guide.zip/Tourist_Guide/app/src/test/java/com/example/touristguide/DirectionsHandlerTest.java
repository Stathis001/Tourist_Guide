package com.example.touristguide;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polyline;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import java.util.List;

public class DirectionsHandlerTest {

    @Mock
    GoogleMap mockMap;

    private DirectionsHandler directionsHandler;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        directionsHandler = new DirectionsHandler();
    }

    @Test
    public void testDrawDirections() {
        LatLng origin = new LatLng(0, 0);
        LatLng destination = new LatLng(1, 1);
        String apiKey = BuildConfig.MAPS_API_KEY;

        directionsHandler.drawDirections(origin, destination, mockMap, apiKey);

        // Verify that execute is called once on a new instance of DirectionsTask
        Mockito.verify(new DirectionsHandler.DirectionsTask(mockMap), times(1)).execute(ArgumentMatchers.anyString());
    }

    @Test
    public void testBuildDirectionsUrl() {
        LatLng origin = new LatLng(0, 0);
        LatLng destination = new LatLng(1, 1);
        String apiKey = BuildConfig.MAPS_API_KEY;

        String url = directionsHandler.buildDirectionsUrl(origin, destination, apiKey);

        // Check if the URL is constructed correctly
        String expectedUrl = "https://maps.googleapis.com/maps/api/directions/json" +
                "?origin=0.0,0.0" +
                "&destination=1.0,1.0" +
                "&mode=driving" +
                "&key=YOUR_API_KEY";
        assertEquals(expectedUrl, url);
    }

    @Test
    public void testClearPolylines() {
        // Mock a Polyline for testing
        Polyline mockPolyline = Mockito.mock(Polyline.class);
        directionsHandler.getPolylines().add(mockPolyline);

        directionsHandler.clearPolylines();

        // Verify that remove is called once on the mockPolyline
        Mockito.verify(mockPolyline, times(1)).remove();

        // Verify that the polylines list is cleared
        assertEquals(0, directionsHandler.getPolylines().size());
    }

    @Test
    public void testGetPolylines() {
        List<Polyline> polylines = directionsHandler.getPolylines();

        // Verify that the returned list is not null
        assertNotNull(polylines);

        // Verify that the returned list is the same as the internal list
        assertEquals(polylines, directionsHandler.getPolylines());
    }
}